// config/database.js
module.exports = {

    'url' : 'mongodb+srv://data:data@cluster0.xmivh.mongodb.net/data?retryWrites=true&w=majority', // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    'dbName': 'demo'
};
